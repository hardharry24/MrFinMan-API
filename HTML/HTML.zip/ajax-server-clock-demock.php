<?Php
		echo date("D F d, Y  h:i:s A", time());
?>